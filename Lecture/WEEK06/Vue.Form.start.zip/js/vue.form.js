/*! vue.form.js © yamoo9.net, 2017 */
;(function(global, Vue){
  'use strict';



})(window, window.Vue);
